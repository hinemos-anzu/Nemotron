=== Nemotron オフライントレーニングパッケージ ===

【手順】

1. インターネットがある環境でモデルをダウンロード:
   pip install transformers
   python scripts/download_model.py \
       --model_name nvidia/Llama-3.1-Nemotron-Nano-8B-v1 \
       --save_dir ./model_cache/nemotron-8b

2. 依存パッケージをインストール:
   pip install -r requirements.txt

3. インターネットをオフにしてトレーニング実行:
   bash run_training.sh
   # アダプタは ./adapter_output/ に保存される

【出力ファイル】
  adapter_output/adapter_model.safetensors
  adapter_output/adapter_config.json

【Kaggle オフラインの場合】
  run_training_kaggle.py の内容をノートブックセルに貼り付けてください。
  (事前にこのzipをKaggleデータセットとしてアップロード)

【推奨トレーニング設定 (RTX PRO6000 / A100)】
  --epochs 1 --batch_size 2 --grad_accum 4 --max_seq_len 512
  → 約100ステップ、2〜3時間で完了
