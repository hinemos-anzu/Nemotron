=== Nemotron オフライントレーニングパッケージ ===

【手順】

1. インターネットがある環境でモデルをダウンロード:
   pip install transformers
   python scripts/download_model.py \
       --model_name nvidia/Llama-3.1-Nemotron-Nano-8B-v1 \
       --save_dir ./model_cache/nemotron-8b
   ※ model_cache/ フォルダはこのフォルダ内に作成されます

2. 依存パッケージをインストール:
   pip install -r requirements.txt

3. zipを展開してこのフォルダに入ってからスクリプトを実行:
   unzip nemotron_offline.zip
   cd nemotron_offline
   bash run_training.sh
   # アダプタは ./adapter_output/ に保存される

【重要】run_training.sh は nemotron_offline/ フォルダの中にあります。
  解凍した場所ではなく、必ず cd nemotron_offline してから実行してください。

【出力ファイル】
  nemotron_offline/adapter_output/adapter_model.safetensors
  nemotron_offline/adapter_output/adapter_config.json

【Kaggle オフラインの場合】
  run_training_kaggle.py の内容をノートブックセルに貼り付けてください。
  (事前にこのzipをKaggleデータセットとしてアップロード)

【推奨トレーニング設定 (RTX PRO6000 / A100)】
  --epochs 1 --batch_size 2 --grad_accum 4 --max_seq_len 512
  → 約100ステップ、2〜3時間で完了
