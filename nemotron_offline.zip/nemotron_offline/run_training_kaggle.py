# ===================================================================
# Kaggle オフライン実行用セル (インターネット無効時)
# 事前準備:
#   1. このzipをKaggleデータセットとしてアップロード
#      (例: dataset名 = "nemotron-offline-pkg")
#   2. モデルをKaggleデータセットとして追加
#      nvidia/nemotron → /kaggle/input/nvidia/nemotron/...
#      または事前ダウンロード済みzipをデータセットとして追加
# ===================================================================

import sys, os, zipfile, shutil

# --- コード+データの展開 ---
PKG_ZIP   = "/kaggle/input/nemotron-offline-pkg/nemotron_offline.zip"
WORK_DIR  = "/kaggle/working/Nemotron"

if os.path.exists(WORK_DIR):
    shutil.rmtree(WORK_DIR)

with zipfile.ZipFile(PKG_ZIP) as z:
    z.extractall("/kaggle/working/")

# zipの中身は nemotron_offline/ → WORK_DIR にリネーム
os.rename("/kaggle/working/nemotron_offline", WORK_DIR)

sys.path.insert(0, f"{WORK_DIR}/scripts")
os.chdir(WORK_DIR)
print("Setup done:", os.listdir(WORK_DIR))

# --- モデルパス (Kaggle model or ローカルキャッシュ) ---
# オプション1: KaggleにあるNVIDIA Nemotronモデルを使う場合
MODEL_PATH = "/kaggle/input/nvidia/nemotron/transformers/llama-3.1-nemotron-nano-8b-v1/1"
# オプション2: 自前でアップロードしたモデルキャッシュ
# MODEL_PATH = "/kaggle/input/nemotron-model-cache/nemotron-8b"

# --- トレーニング実行 ---
import subprocess
result = subprocess.run([
    "python", f"{WORK_DIR}/scripts/train_sft.py",
    "--corpus",     f"{WORK_DIR}/reports/cryptarithm/corpus.jsonl",
    "--output_dir", "/kaggle/working/adapter",
    "--model_name", MODEL_PATH,
    "--lora_r",     "16",
    "--lora_alpha", "32",
    "--epochs",     "1",
    "--batch_size", "2",
    "--grad_accum", "4",
    "--lr",         "2e-4",
    "--max_seq_len","512",
], check=True)
