#!/bin/bash
# オフラインでのトレーニング実行スクリプト
# 事前に download_model.py でモデルをダウンロードしておくこと

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODEL_DIR="${SCRIPT_DIR}/model_cache/nemotron-8b"

if [ ! -d "$MODEL_DIR" ]; then
    echo "ERROR: モデルが見つかりません: $MODEL_DIR"
    echo "インターネットがある環境で先に実行してください:"
    echo "  python scripts/download_model.py --save_dir $MODEL_DIR"
    exit 1
fi

python "${SCRIPT_DIR}/scripts/train_sft.py" \
    --corpus  "${SCRIPT_DIR}/reports/cryptarithm/corpus.jsonl" \
    --output_dir "${SCRIPT_DIR}/adapter_output" \
    --model_name "${MODEL_DIR}" \
    --lora_r 16 \
    --lora_alpha 32 \
    --epochs 1 \
    --batch_size 2 \
    --grad_accum 4 \
    --lr 2e-4 \
    --max_seq_len 512
